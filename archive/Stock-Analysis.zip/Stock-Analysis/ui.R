

rm(list = ls())

suppressWarnings({
  library(shiny)
  library(shinydashboard)
  library(waiter) # spin_ripple()
  library(sparkline)
  library(shinyjs)
  library(xkcd)
  library(shinyscreenshot)
  library(plotly)
  library(shinyWidgets)
  library(shinythemes)
  # library(semantic.dashboard)
  library(DT)
  library(sass)
  library(tidyverse)
  library(quantmod)
  library(PerformanceAnalytics)
  library(lubridate)
  library(ggthemes)
  library(htmlwidgets) # 0.4 MB
  library(ggrepel) # 0.1 MB
  library(magrittr)
  library(slider)
  library(shinycssloaders)
  # library(sever) # Disconnection message
})

conflict_prefer("renderDataTable", "shiny", quiet = TRUE)
conflict_prefer("box", "shinydashboard", quiet = TRUE)

# Source all modules
lapply(
    list.files("modules", pattern = ".R", full.names = TRUE),
    FUN = function(x)
        source(x)
)



# Load data
source("data.R")
source("code/helper functions.R")


# Convert Sass to CSS
sass(sass_file("www/custom.scss"),
     output = "www/custom.css",
     cache = FALSE)


ui <- tagList(
  dashboardPage(
  useShinyjs(),
    skin = "red", #"red-light", #c("deeppink2", "mistyrose3", "steelblue1")red-light"), #"midnight", "black-light"
    
    # sidebar_background = NULL,
    
    header = dashboardHeader(
      title = "Stock Analysis"
      ),
    
    sidebar = dashboardSidebar(
      sidebarUserPanel(
            "Aaron Hardy",
            subtitle = a(href = "#", icon("circle", class = "text-success"), "Online"),
            # Image file should be in www/ subdir
            image = "profile_pic.png"
        ),
        sidebarMenu(
            # Setting id makes input$tabs give the tabName of currently-selected tab
            id = "tabs",
            menuItem(
                "Charts",
                icon = icon("far fa-chart-bar"),
                menuSubItem("Economy", tabName = "economy"),
                menuSubItem("Securities", tabName = "securities", selected = TRUE),
                startExpanded = TRUE
            )
        )
    ),
    body = dashboardBody(
      
      # Link to js file
      includeScript(path = "www/script.js"),
      
      # Link to css file
      includeCSS("www/custom.css"),
      
        # setShadow(class = "box"),
        tabItems(
            tabItem(
              tabName = "economy",
              mod_charts_economy_ui("economy",
                                    dates_gdp = dates_gdp, 
                                    dates_yields = dates_yields, 
                                    dates_inflation = dates_inflation, 
                                    dates_bond_yields = dates_bond_yields)
            ),
            tabItem(
              tabName = "securities",
              mod_charts_securities_ui(id = "securities",
                                       industry_choices = industry_choices,
                                       ratio_choices = ratio_choices)
              
            )
        )
    )
  ),
  tags$footer(
    paste("Aaron Hardy", format(Sys.Date(), "%Y")),
    align = "center",
    style = 
      "position:relative;
    color:white;
    bottom:0;
    width:100%;
    heght:50px;
    padding:10px;
    background-color:#707070;"
  )
  
)
