
document.body.style.backgroundColor = "skyblue";

