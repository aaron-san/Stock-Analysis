
server <- function(input, output, session) {
    mod_charts_economy_server(id = "economy",
                              yields_monthly = yields_monthly, 
                              gdp = gdp, 
                              inflation = inflation, 
                              bond_yields = bond_yields)
    mod_dashboard_server(id = "dashboard_about")
    mod_charts_securities_server(id = "securities",
                                 ratios = ratios,
                                 ratio_functions = ratio_functions,
                                 ratio_guide = ratio_guide)
    
}