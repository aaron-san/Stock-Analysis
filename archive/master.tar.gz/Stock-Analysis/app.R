

rm(list = ls())
# ORACLE, TESLA, HP moving to TX from CA


suppressWarnings({
  library(shiny)
  library(shinydashboard)
  library(waiter) # spin_ripple()
  library(sparkline)
  library(shinyjs)
  library(xkcd)
  library(shinyscreenshot)
  library(plotly)
  library(shinyWidgets)
  library(shinythemes)
  # library(semantic.dashboard)
  library(DT)
  library(sass)
  library(tidyverse)
  library(quantmod)
  library(PerformanceAnalytics)
  library(lubridate)
  library(ggthemes)
  library(htmlwidgets) # 0.4 MB
  library(ggrepel) # 0.1 MB
  library(magrittr)
  library(slider)
  library(shinycssloaders)
  # library(sever) # Disconnection message
})

conflict_prefer("renderDataTable", "shiny", quiet = TRUE)
conflict_prefer("box", "shinydashboard", quiet = TRUE)

# Source all modules
lapply(
    list.files("modules", pattern = ".R", full.names = TRUE),
    FUN = function(x)
        source(x)
)



# Load data
source("data.R")
source("code/helper functions.R")


# Convert Sass to CSS
sass(sass_file("www/custom.scss"),
     output = "www/custom.css",
     cache = FALSE)


###########
### UI ####
###########

ui <- tagList(
  dashboardPage(
  useShinyjs(),
    skin = "red", #"red-light", #c("deeppink2", "mistyrose3", "steelblue1")red-light"), #"midnight", "black-light"
    
    # sidebar_background = NULL,
    
    header = dashboardHeader(
      title = "Stock Analysis"
      ),
    
    sidebar = dashboardSidebar(
      sidebarUserPanel(
            "Aaron Hardy",
            subtitle = a(href = "#", icon("circle", class = "text-success"), "Online"),
            # Image file should be in www/ subdir
            image = "profile_pic.png"
        ),
        sidebarMenu(
            # Setting id makes input$tabs give the tabName of currently-selected tab
            id = "tabs",
            menuItem(
                "Charts",
                icon = icon("far fa-chart-bar"),
                menuSubItem("Economy", tabName = "economy"),
                menuSubItem("Securities", tabName = "securities", selected = TRUE),
                startExpanded = TRUE
            )
        )
    ),
    body = dashboardBody(
      
      # Link to js file
      includeScript(path = "www/script.js"),
      
      # Link to css file
      includeCSS("www/custom.css"),
      
        # setShadow(class = "box"),
        tabItems(
            tabItem(
              tabName = "economy",
              mod_charts_economy_ui("economy",
                                    dates_gdp = dates_gdp, 
                                    dates_yields = dates_yields, 
                                    dates_inflation = dates_inflation, 
                                    dates_bond_yields = dates_bond_yields)
            ),
            tabItem(
              tabName = "securities",
              mod_charts_securities_ui(id = "securities",
                                       industry_choices = industry_choices,
                                       ratio_choices = ratio_choices)
              
            )
        )
    )
  ),
  tags$footer(
    paste("Aaron Hardy", format(Sys.Date(), "%Y")),
    align = "center",
    style = 
      "position:relative;
    color:white;
    bottom:0;
    width:100%;
    heght:50px;
    padding:10px;
    background-color:#707070;"
    # z-index: 100;"
    # HTML('<footer class="main-footer"><div class="pull-right hidden-xs">2022</div>
    # By Aaron Hardy</footer>'
  )
  
)


##############
### Server ###
##############

server <- function(input, output, session) {
    mod_charts_economy_server(id = "economy",
                              yields_monthly = yields_monthly, 
                              gdp = gdp, 
                              inflation = inflation, 
                              bond_yields = bond_yields)
    mod_dashboard_server(id = "dashboard_about")
    mod_charts_securities_server(id = "securities",
                                 ratios = ratios,
                                 ratio_functions = ratio_functions,
                                 ratio_guide = ratio_guide)
    
}





# library(gapminder) # for gapminder dataset
# library(plotly) # for plotly charts and %>% pipe operator
#
# ## Size of the scatter data point will represent the population
# ## Color of the scatter data point will represent the continent
#
# gapminder %>%
#     plot_ly() %>%
#     # add frame argument for animation and map to the variable needed on the timeline
#     add_markers(x=~gdpPercap, y=~lifeExp,
#                 frame=~year,
#                 size = ~pop,
#                 color=~continent,
#                 marker=list(sizemode="diameter"),
#                 text=~paste("Life Expectancy: ", round(lifeExp,1),
#                             "<br>",
#                             "GDP Per Capita:", round(gdpPercap,1),
#                             "<br>",
#                             "Country:", country,
#                             "<br>",
#                             "Population:", pop),
#                 hoverinfo= "text") %>%
#     layout(title="Animated Plotly Bubble Plot",
#            xaxis=list(title="GDP Per Capita (log scale)", type="log"),
#            yaxis=list(title= "Life Expectancy"))








shinyApp(ui = ui, server = server)
